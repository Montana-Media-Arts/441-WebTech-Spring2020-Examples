/*
Author: Michael Cassens
File Name: My Page.html

Date: Today's Date
Purpose: To explain comments
*/

// Author: Michael Cassens
// File Name: My Page.html
// Date: Today's Date
// Purpose: To explain comments

// this is our single line comment for our console.log

console.log("JavaScript Rules!");